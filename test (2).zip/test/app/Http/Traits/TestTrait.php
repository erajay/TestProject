<?php
namespace App\Http\Traits;
use App\User;

trait TestTrait {
public function all_address() {
        
       $address = User::find(1)->address;
       return $address;
    }
}
    ?>